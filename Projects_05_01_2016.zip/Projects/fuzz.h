//---------------------------------------------------------------------------

#ifndef fuzzH
#define fuzzH
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
#include <Vcl.ComCtrls.hpp>
#include <Vcl.Dialogs.hpp>
#include <Data.Bind.Components.hpp>
#include <Data.Bind.EngExt.hpp>
#include <Vcl.Bind.DBEngExt.hpp>
#include <Vcl.ExtCtrls.hpp>
#include <Vcl.Imaging.jpeg.hpp>
#include <System.ImageList.hpp>
#include <Vcl.ImgList.hpp>
#include <Vcl.Grids.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TButton *Open;
	TButton *Play;
	TButton *Pause;
	TButton *Stop;
	TTrackBar *TrackBar_Volume;
	TOpenDialog *OpenDialog1;
	TLabel *TimeBegin;
	TTrackBar *TrackBar_Time;
	TTimer *TimerTrack;
	TLabel *TimeEnd;
	TImage *Image1;
	TListBox *ListBox1;
	TButton *Previous;
	TButton *Next;
	TLabel *ID3_title;
	TLabel *ID3_artist;
	TLabel *ID3_album;
	TLabel *ID3_year;
	TButton *add;
	TButton *take;
	TLabel *FormatSound;
	TPanel *Panel1;
	TPanel *Panel2;
	TPanel *Panel3;
	TLabel *ID3_track;
	TTrayIcon *TrayIcon1;
	TStatusBar *StatusBar1;
	TLabel *PlayMode;
	void __fastcall OpenClick(TObject *Sender);
	void __fastcall PlayClick(TObject *Sender);
	void __fastcall StopClick(TObject *Sender);
	void __fastcall PauseClick(TObject *Sender);
	void __fastcall TrackBar_VolumeChange(TObject *Sender);
	void __fastcall TimerTrackTimer(TObject *Sender);
	void __fastcall TrackBar_TimeChange(TObject *Sender);
	void __fastcall ListBox1DblClick(TObject *Sender);
	void __fastcall NextClick(TObject *Sender);
	void __fastcall PreviousClick(TObject *Sender);
	void __fastcall addClick(TObject *Sender);
	void __fastcall takeClick(TObject *Sender);
	void __fastcall ListBox1DrawItem(TWinControl *Control, int Index, TRect &Rect, TOwnerDrawState State);
	void __fastcall ListBox1KeyPress(TObject *Sender, System::WideChar &Key);
	void __fastcall takeMouseEnter(TObject *Sender);
	void __fastcall takeMouseLeave(TObject *Sender);
	void __fastcall ListBox1MouseLeave(TObject *Sender);
	void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
	void __fastcall ListBox1MouseMove(TObject *Sender, TShiftState Shift, int X, int Y);
	void __fastcall OpenMouseEnter(TObject *Sender);









private:	// User declarations
 void __fastcall DoShowHint(UnicodeString &HintStr, bool &CanShow,THintInfo &HintInfo);
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
